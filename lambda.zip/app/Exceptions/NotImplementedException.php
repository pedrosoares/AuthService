<?php

namespace App\Exceptions;

/**
 * Class NotImplementedException
 * @package App\Exceptions
 */
class NotImplementedException extends \Exception
{

}